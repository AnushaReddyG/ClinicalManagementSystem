package com.dop.cms.dataHolder;

public class DoctorGetsSets {
	
	private String apptstatus;
	private String  apptdate;
	private String patientid;
	
	
	
	public String getApptStatus() {
		return apptstatus;
	}
	public void setApptStatus(String apptstatus) {
		this.apptstatus = apptstatus;
	}
	public String getApptDate() {
		return apptdate;
	}
	public void setApptDate(String apptdate) {
		this.apptdate = apptdate;
	}
	
	public String getPatientId() {
		return patientid;
	}
	public void setPatientId(String patientid) {
		this.patientid = patientid;
	}

}
