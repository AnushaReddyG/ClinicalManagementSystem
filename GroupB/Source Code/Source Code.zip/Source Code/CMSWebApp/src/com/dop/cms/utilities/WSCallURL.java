package com.dop.cms.utilities;

public class WSCallURL {
	/*
	public static String LOGINMODULE ="http://54.149.105.39:8080/LoginModule/LoginService";
	public static String LABASSISTMODULE ="http://54.69.208.233:8080/LabAsstModule/LabService";
	public static String DOCTORMODULE ="http://54.68.75.154:8080/DoctorWS/DoctorService";
	public static String PATIENTMODULE ="http://54.149.41.219:8080/PatientWS/PatientService";
	public static String STAFFMODULE ="http://54.148.100.126:8080/StaffModule/StaffService";


	Login, doctor, patient - 54.149.105.39
	public static String LOGINMODULE ="http://54.149.79.185:8080/LoginModule/LoginService";
	public static String LABASSISTMODULE ="http://54.69.208.233:8080/LabAsstModule/LabService";
	public static String DOCTORMODULE ="http://54.68.75.154:8080/DoctorWS/DoctorService";
	public static String PATIENTMODULE ="http://54.149.41.219:8080/PatientWS/PatientService";
	public static String STAFFMODULE ="http://54.148.100.126:8080/StaffModule/StaffService";

 */
	public static String LOGINMODULE ="http://localhost:1000/LoginModule/LoginService";
	public static String LABASSISTMODULE ="http://localhost:1000/LabAsstModule/LabService";
	public static String DOCTORMODULE ="http://localhost:1000/DoctorWS/DoctorService";
	public static String PATIENTMODULE ="http://localhost:1000/PatientWS/PatientService";
	public static String STAFFMODULE ="http://localhost:1000/StaffModule/StaffService";

	
}
