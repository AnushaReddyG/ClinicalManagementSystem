package com.dop.cms.utilities;

//details for connecting to database
public class DBDetails {


	public static String URL ="jdbc:mysql://localhost:3306/clinicdb";
	public static String USERNAME ="root";
	public static String PASSWORD ="";
	
	
}
