package com.dop.cms.data;

public class DBDetails {

//	public static String URL ="jdbc:mysql://54.149.79.185:3306/clinicdb";
	public static String URL ="jdbc:mysql://localhost:3306/clinicdb";
	public static String USERNAME ="root";
	public static String PASSWORD ="";
	
	
}
